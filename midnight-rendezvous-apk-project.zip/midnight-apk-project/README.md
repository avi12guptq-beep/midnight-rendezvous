# Midnight Rendezvous — Android build

This folder is a ready-to-go Capacitor project. Your app's built files are
already sitting in `www/`. Run these on your own computer (needs internet
and ~10 min the first time).

## Prerequisites (one-time)
1. Install [Node.js](https://nodejs.org) (LTS).
2. Install [Android Studio](https://developer.android.com/studio) — this
   gives you the Android SDK and build tools. Open it once after install
   so it finishes downloading the SDK.

## Option A: cloud build (no local install at all)
1. Create a free GitHub account if you don't have one, and a new **public**
   repo (private works too, just uses your monthly free Actions minutes).
2. Upload every file in this folder to that repo (drag-and-drop on
   github.com works fine — no git command line needed).
3. Go to the repo's **Actions** tab. The included workflow
   (`.github/workflows/build-apk.yml`) runs automatically and builds the
   APK on GitHub's servers.
4. When the run finishes (green check), open it and download the
   `midnight-rendezvous-debug-apk` artifact — that's your `.apk`.

This costs nothing and needs zero installs on your computer.

## Option B: build it yourself locally
```bash
# 1. From this project folder, install Capacitor
npm install

# 2. Add the Android platform (creates an android/ folder)
npx cap add android

# 3. Copy www/ into the native project
npx cap sync android

# 4a. Easiest: open in Android Studio and build/run from there
npx cap open android
#     Then: Build > Build Bundle(s)/APK(s) > Build APK(s)
#     Output: android/app/build/outputs/apk/debug/app-debug.apk

# 4b. Or build from the command line instead of step 4a
cd android
./gradlew assembleDebug
#     Output: app/build/outputs/apk/debug/app-debug.apk
```

That debug APK installs directly on a phone (enable "install unknown apps")
or an emulator. For a Play Store release build you'd generate a signed AAB
instead — Android Studio's Build menu has a wizard for that
(Build > Generate Signed Bundle / APK).

## Before you build, two small things worth knowing
- `www/index.html` links to `/__grok/manifest.webmanifest` and an external
  `grok.com/grok-app-builder/extensions.js` script — leftovers from
  wherever this was originally built/hosted. They won't break the APK
  (the script tag is `defer` and just fails silently offline), but you
  can delete both `<link>`/`<script>` lines from `www/index.html` for a
  cleaner offline build.
- The Google Fonts `<link>` in the same file needs internet to load on
  first run. If you want the app to look right with no connection at all,
  download those font files and reference them locally instead.

## Change before publishing
- `appId` in `capacitor.config.json` (`com.example.midnightrendezvous`) is
  a placeholder — set it to your own reverse-domain package name before
  you release anything.
